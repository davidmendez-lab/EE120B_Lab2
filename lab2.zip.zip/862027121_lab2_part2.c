/*	Author: David MEndez
 *  Partner(s) Name: 
 *	Lab Section: 022
 *	Assignment: Lab 2  Exercise 2
 *	Exercise Description: [optional - include for your own benefit]
 *
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#ifdef _SIMULATE_
#include "simAVRHeader.h"
#endif


//inputs = pin outputs = port
int main(void)
{
    /* Insert DDR and PORT initializations */
	DDRA = 0x00; PORTA = 0x0F; //all 8 pins as inputs  
	DDRC = 0xFF; PORTC = 0x00; //all 8 pins as outputs
	
	unsigned char cntavail;
    	while (1)
		{
		if(PINA == 0x00)
			{
			cntavail = 0x04;
			}
		else if((PINA == 0x01) || (PINA == 0x02) || (PINA == 0x04) || (PINA == 0x08))
			{
			cntavail = 0x03;
			}
		else if((PINA == 0x07) || (PINA == 0x0B) || (PINA == 0x0D) || (PINA == 0x0E))
			{
			cntavail = 0x01;
			}
		else if(PINA == 0x0F)
			{
			cntavail = 0x00;
			}
		else if((PINA == 0x10) || (PINA == 0x20) || (PINA == 0x30)||(PINA == 0x40)||(PINA == 0x50) || (PINA == 0x60)||(PINA == 0x70)||(PINA == 0x80)||(PINA == 0x90)||(PINA == 0xA0)||(PINA == 0xB0)||(PINA == 0xC0)||(PINA == 0xD0)||(PINA == 0xE0)||(PINA == 0xF0))
			{
			cntavail = 0x04;
			}
		else if((PINA == 0x1F) || (PINA == 0x2F) || (PINA == 0x3F)||(PINA == 0x4F)||(PINA == 0x5F) || (PINA == 0x6F)||(PINA == 0x7F)||(PINA == 0x8F)||(PINA == 0x9F)||(PINA == 0xAF)||(PINA == 0xBF)||(PINA == 0xCF)||(PINA == 0xDF)||(PINA == 0xEF)||(PINA == 0xFF))
			{
			cntavail = 0x00;
			}
		else
			{
			cntavail = 0x02;
			}
		PORTC = cntavail;
		}
		
   return 1;    

}
